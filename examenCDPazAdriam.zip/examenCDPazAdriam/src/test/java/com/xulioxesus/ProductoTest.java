package com.xulioxesus;

import org.junit.jupiter.api.Test;

public class ProductoTest {
    @Test
    void testGetCantidad() {

    }

    @Test
    void testGetNombre() {

    }

    @Test
    void testGetPrecio() {

    }

    @Test
    void testGetTotal() {

    }

    @Test
    void testToString() {

    }
}
